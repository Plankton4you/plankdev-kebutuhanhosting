import MainApp from "@/components/main-app"

export default function HomePage() {
  return <MainApp />
}
